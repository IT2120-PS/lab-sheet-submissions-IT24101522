setwd("D:\\SLIIT\\PS\\IT24101522")

#(1)
  #i  Binomial Distribution
      #Here, Random variable X has Binomial Distribution with n=50 and p=0.85

  #ii
      pbinom(47,50,0.85,lower.tail = FALSE)
      
#(2)
      
      #i Customer Calls per hour
      
      #ii Poisson Distribution 
      # Here, Random variable X has Poisson Distribution with λ=12
      
      #iii
      dpois(15,12)


