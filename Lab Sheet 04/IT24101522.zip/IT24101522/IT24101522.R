setwd("C:/Users/it24101522/Desktop/IT24101522")

# Read the dataset
branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",") # seperate the tables
# Check the first few rows
head(branch_data)

# Check structure of the data
str(branch_data)

# Check summary statistics
summary(branch_data)

boxplot(branch_data$Sales_X1,
        main="Boxplot of Sales", 
        ylab="Sales", col="lightblue")

fivenum(branch_data$Advertising_X2) #five numbr summery
IQR(branch_data$Advertising_X2)   # Calculate IQR

find_outliners <- function(x){
  Q1 <- quantile(x,0.25)
  Q3 <- quantile(x,0.75)
  IQR_value <- IQR(x)
  
  lower <- Q1 - 1.5 * IQR_value
  upper <- Q3 + 1.5 * IQR_value
  
  outliners <- x[x<lower | x > upper]
  return(outliners)
}

#check outliners in 'years' variable
find_outliners(branch_data$Years_X3)







